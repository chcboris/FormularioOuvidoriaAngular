import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denuncia',
  templateUrl: './denuncia.component.html',
  styleUrls: ['./denuncia.component.css']
})
export class DenunciaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
