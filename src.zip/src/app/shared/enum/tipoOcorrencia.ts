export  enum TipoOcorrencia {
    RECLAMACAO = 1,
    DENUNCIA = 2,
    SUGESTAO = 3
  }
