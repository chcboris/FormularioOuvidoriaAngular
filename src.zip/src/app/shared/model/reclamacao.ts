export interface Reclamacao {
    nomeRG?: string;
    nomeSocial?: string;
    nascimento?: string;
    nomeMae?: string;
    titulo?: string;
    sexo?: string;
    escolaridade?: string;
    email?: string;
    cep?:string;
    estado?:string;
    cidade?:string;
    endereco?:string;
    bairro?:string;
    local?:string;
    ocorrencia?:string
    }